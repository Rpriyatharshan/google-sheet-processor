import { Component } from '@angular/core';

@Component({
  selector: 'app-connection-page',
  standalone: true,
  imports: [],
  templateUrl: './connection-page.component.html',
  styleUrl: './connection-page.component.css'
})
export class ConnectionPageComponent {
connect(){
  console.log('test')
  console.log('test')
  console.log('test')
}
}

