import { Routes } from '@angular/router';
import { ConnectionPageComponent } from './connection-page/connection-page.component';

export const routes: Routes = [{
    path: "connection",
    component: ConnectionPageComponent,
    pathMatch:"full"
}];
